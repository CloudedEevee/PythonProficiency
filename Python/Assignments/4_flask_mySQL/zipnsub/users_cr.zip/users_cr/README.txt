To access the database, please use the following file:

flask_app\config\dbFE_`users_schema`.txt