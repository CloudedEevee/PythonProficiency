# Basic print
print("Hello World")



# Printing with variables
    # Name
my_name = "Makayla"
        # With comma
print("Hello", my_name +"!")
        # With +
print("Hello " + my_name + "!")
    # Number
my_fave_num = 3
        # With comma
print("Hello", str(my_fave_num) +"!")
        # With +
print("Hello " + str(my_fave_num) +"!")
    # Food
food_one = "spaghetti"
food_two = "red bean salad"
        # With format method
print("I love to eat {} and {}.".format(food_one, food_two))
        # With f-strings
print(f"I love to eat {food_one} and {food_two}.")
        # Bonus: %-formatting
print("I love to eat %s and %s" % (food_one, food_two))