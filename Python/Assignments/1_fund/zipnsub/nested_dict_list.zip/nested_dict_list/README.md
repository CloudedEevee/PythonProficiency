*Here is the map for where each code block answer is for each question:*




1: Update Values in Dictionaries and Lists
    See "update.py"

2: Iterate Through a List of Dictionaries
    See "iterate.py"

3: Get Values From a List of Dictionaries
    See "get_values.py"

4: Iterate Through a Dictionary with List Values
    See "iterate.py"



